import { Component, OnInit } from '@angular/core';
import { UserService } from '../sevice/user.service';

declare var $: any;


@Component({
  selector: 'app-aside',
  templateUrl: './aside.component.html',
  styleUrls: ['./aside.component.scss'],
  host:{
    '(document:click)': 'closeMenu()'
  }
})

export class AsideComponent implements OnInit {

  isvisible: boolean = false;
  userData:any;


  constructor(private user: UserService) { }

  ngOnInit() {
    $("#btn").on('click', function () {
      $(".accordionSection").slideToggle();
      $('aside').toggleClass('asideActive');

    })
      this.user.fetchData().
      subscribe(
        res=>{
          this.userData=res;
        }
      )
  }

  closeMenu(){
    var $trigger = $(".leftPanel");
    if ($trigger !== event.target && !$trigger.has(event.target).length) {
      $(".accordionSection").slideUp(function (){
        $('aside').removeClass('asideActive');
      });
    }
  }

}
