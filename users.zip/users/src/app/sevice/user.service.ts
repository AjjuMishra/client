import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class UserService {

  constructor( private http: HttpClient) { }

  fetchData(){
    return this.http.get('https://my-json-server.typicode.com/AjjuMishra/client/users'); 
  }

}
